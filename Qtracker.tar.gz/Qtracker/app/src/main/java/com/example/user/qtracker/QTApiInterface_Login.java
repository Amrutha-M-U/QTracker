package com.example.user.qtracker;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by user on 8/7/16.
 */

public interface QTApiInterface_Login{
    @POST("api/loginUser")
    Call<QTUser> createUser(@Body QTUser object);
}
