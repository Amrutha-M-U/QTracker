package com.example.user.qtracker;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class QTLogin_MainActivity extends AppCompatActivity{

    private EditText username,password;
    private Button signin;
    private TextView register,forgot_password;
//    private String id = Secure.getString(getContentResolver(), Secure.ANDROID_ID);
private String id="fdfddgdgd";
    public  String user,pswd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.temp);
        init();

        signin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View V) {
                username = (EditText) findViewById(R.id.Username);
                password = (EditText) findViewById(R.id.Password);
                user = username.getText().toString();
                pswd = password.getText().toString();
                    QTUser object = new QTUser(user, pswd, id);


                    QTApiInterface_Login apiService =
                            QTApiClient_Login.getClient().create(QTApiInterface_Login.class);
                    Call<QTUser> call = apiService.createUser(object);

                    call.enqueue(new Callback<QTUser>() {
                        @Override
                        public void onResponse(Call<QTUser> call, Response<QTUser> response) {
                            if (response.body() != null)
                                Toast.makeText(QTLogin_MainActivity.this, "Success",
                                        Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(QTLogin_MainActivity.this, "empty", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailure(Call<QTUser> call, Throwable t) {
                            Toast.makeText(QTLogin_MainActivity.this, "OnFailure)",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }


        });
    }
    private void init(){

        signin = (Button)findViewById(R.id.Sign_in);
        register = (TextView)findViewById(R.id.registertext);
        forgot_password = (TextView)findViewById(R.id.forgotText);
    }

    /**
     * Created by user on 8/7/16.
     */
    public static class QTRegister_MainActivity {
    }
}
